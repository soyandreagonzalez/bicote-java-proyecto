
package bicote;

public class BicoteMain {


    public static void main(String[] args) {
        Comienzo inicio = new Comienzo();
        inicio.setVisible(true);
    }
    
}
